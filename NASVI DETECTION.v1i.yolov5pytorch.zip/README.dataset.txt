# NASVI DETECTION > 2023-06-04 5:18pm
https://universe.roboflow.com/marcelo-velasquez/nasvi-detection

Provided by a Roboflow user
License: CC BY 4.0

