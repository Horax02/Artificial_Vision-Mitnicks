# NASVI PADIMENT > 2023-06-04 5:39pm
https://universe.roboflow.com/marcelo-velasquez/nasvi-padiment

Provided by a Roboflow user
License: CC BY 4.0

